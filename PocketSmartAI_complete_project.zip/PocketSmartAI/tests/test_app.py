import os
from pathlib import Path
os.environ["DATABASE_PATH"] = str(Path(__file__).parent / "test.db")
os.environ["SECRET_KEY"] = "test-secret"
from fastapi.testclient import TestClient
from app.main import app

def test_health():
    with TestClient(app) as c:
        r=c.get("/api/health")
        assert r.status_code==200 and r.json()["status"]=="ok"

def test_register_plan_history():
    with TestClient(app) as c:
        r=c.post("/api/auth/register",json={"name":"Test User","email":"testuser@example.com","password":"StrongPass123"})
        assert r.status_code==201,r.text
        h={"Authorization":"Bearer "+r.json()["access_token"]}
        p=c.post("/api/generate-home",headers=h,json={"budget":10000,"room_type":"Bedroom","style":"Modern","currency":"INR","items":["Lighting","Storage"],"notes":""})
        assert p.status_code==200,p.text
        assert p.json()["items"]
        assert c.get("/api/history",headers=h).status_code==200

def test_history_requires_login():
    with TestClient(app) as c:
        assert c.get("/api/history").status_code==401
