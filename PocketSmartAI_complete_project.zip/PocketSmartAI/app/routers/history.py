import json
from fastapi import APIRouter, Depends, HTTPException
from app.database import get_db
from app.routers.auth import get_current_user
router=APIRouter(prefix="/api",tags=["history"])
@router.get("/history")
def history(user=Depends(get_current_user)):
    with get_db() as c: rows=c.execute("SELECT id,planner_type,input_json,result_json,created_at FROM recommendations WHERE user_id=? ORDER BY id DESC LIMIT 100",(user["id"],)).fetchall()
    return {"items":[{"id":r["id"],"planner_type":r["planner_type"],"input":json.loads(r["input_json"]),"result":json.loads(r["result_json"]),"created_at":r["created_at"]} for r in rows]}
@router.get("/recommendations/{recommendation_id}")
def details(recommendation_id:int,user=Depends(get_current_user)):
    with get_db() as c: r=c.execute("SELECT id,planner_type,input_json,result_json,created_at FROM recommendations WHERE id=? AND user_id=?",(recommendation_id,user["id"])).fetchone()
    if not r: raise HTTPException(404,"Recommendation not found.")
    return {"id":r["id"],"planner_type":r["planner_type"],"input":json.loads(r["input_json"]),"result":json.loads(r["result_json"]),"created_at":r["created_at"]}
