from fastapi import APIRouter, Depends, HTTPException, Header
from app.schemas import RegisterRequest, LoginRequest
from app.database import get_db, now_iso
from app.security import hash_password, verify_password, create_access_token, decode_access_token
router=APIRouter(prefix="/api/auth",tags=["authentication"])
def get_current_user(authorization: str|None=Header(default=None)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401,"Please log in to continue.")
    p=decode_access_token(authorization.split(" ",1)[1].strip())
    if not p: raise HTTPException(401,"Session expired or invalid. Please log in again.")
    with get_db() as c: row=c.execute("SELECT id,name,email,created_at FROM users WHERE id=?",(p["id"],)).fetchone()
    if not row: raise HTTPException(401,"User account not found.")
    return dict(row)
@router.post("/register",status_code=201)
def register(body:RegisterRequest):
    email=body.email.lower().strip()
    with get_db() as c:
        if c.execute("SELECT id FROM users WHERE email=?",(email,)).fetchone(): raise HTTPException(409,"An account with this email already exists.")
        cur=c.execute("INSERT INTO users(name,email,password_hash,created_at) VALUES(?,?,?,?)",(body.name.strip(),email,hash_password(body.password),now_iso()))
        uid=cur.lastrowid
    return {"access_token":create_access_token(uid,email),"token_type":"bearer","user":{"id":uid,"name":body.name.strip(),"email":email}}
@router.post("/login")
def login(body:LoginRequest):
    email=body.email.lower().strip()
    with get_db() as c: u=c.execute("SELECT * FROM users WHERE email=?",(email,)).fetchone()
    if not u or not verify_password(body.password,u["password_hash"]): raise HTTPException(401,"Incorrect email or password.")
    return {"access_token":create_access_token(u["id"],u["email"]),"token_type":"bearer","user":{"id":u["id"],"name":u["name"],"email":u["email"]}}
@router.post("/logout")
def logout(): return {"message":"Logged out. Remove the saved access token from this browser."}
@router.get("/session-info")
def session_info(user=Depends(get_current_user)): return {"authenticated":True,"user":{"id":user["id"],"name":user["name"],"email":user["email"]}}
@router.get("/session-data")
def session_data(user=Depends(get_current_user)):
    with get_db() as c: n=c.execute("SELECT COUNT(*) n FROM recommendations WHERE user_id=?",(user["id"],)).fetchone()["n"]
    return {"user":{"id":user["id"],"name":user["name"],"email":user["email"]},"recommendation_count":n}
