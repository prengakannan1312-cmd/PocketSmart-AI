from io import BytesIO
from PIL import Image, UnidentifiedImageError
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from app.config import MAX_UPLOAD_MB
from app.database import get_db, now_iso
from app.routers.auth import get_current_user
from app.schemas import HomeRequest, PartyRequest, JewelryRequest
from app.services.recommendations import generate_recommendations
router=APIRouter(prefix="/api",tags=["planners"])
def save_result(user,planner,data,image_bytes=None,mime_type=None):
    result=generate_recommendations(planner,data,image_bytes,mime_type)
    import json
    with get_db() as c:
        cur=c.execute("INSERT INTO recommendations(user_id,planner_type,input_json,result_json,created_at) VALUES(?,?,?,?,?)",(user["id"],planner,json.dumps(data),json.dumps(result),now_iso()))
        rid=cur.lastrowid
    result["recommendation_id"]=rid
    return result
@router.post("/generate-home")
def home(body:HomeRequest,user=Depends(get_current_user)): return save_result(user,"home",body.model_dump())
@router.post("/generate-party")
def party(body:PartyRequest,user=Depends(get_current_user)): return save_result(user,"party",body.model_dump())
@router.post("/generate-jewelry")
async def jewelry(budget:float=Form(gt=0,le=100000000),occasion:str=Form(min_length=2,max_length=80),style:str=Form(default="Classic",max_length=80),outfit_color:str=Form(default="Not specified",max_length=80),material:str=Form(default="Any",max_length=80),currency:str=Form(default="INR",pattern="^(INR|USD|GBP|EUR)$"),notes:str=Form(default="",max_length=500),outfit_image:UploadFile|None=File(default=None),user=Depends(get_current_user)):
    data=JewelryRequest(budget=budget,occasion=occasion,style=style,outfit_color=outfit_color,material=material,currency=currency,notes=notes).model_dump()
    raw=None; mime=None
    if outfit_image and outfit_image.filename:
        if outfit_image.content_type not in {"image/jpeg","image/png","image/webp"}: raise HTTPException(415,"Upload a JPG, PNG, or WebP image.")
        raw=await outfit_image.read()
        if len(raw)>MAX_UPLOAD_MB*1024*1024: raise HTTPException(413,f"Image must be {MAX_UPLOAD_MB} MB or smaller.")
        try:
            with Image.open(BytesIO(raw)) as im: im.verify()
        except (UnidentifiedImageError,OSError): raise HTTPException(400,"The uploaded file is not a valid image.")
        mime=outfit_image.content_type
    return save_result(user,"jewelry",data,raw,mime)
