from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.config import APP_NAME, BASE_DIR, GEMINI_API_KEY, GEMINI_MODEL
from app.database import init_db
from app.routers import auth, planners, history
@asynccontextmanager
async def lifespan(app:FastAPI):
    init_db()
    yield
app=FastAPI(title=APP_NAME,version="1.0.0",description="Budget-aware planning recommendations.",lifespan=lifespan)
app.mount("/static",StaticFiles(directory=str(BASE_DIR/"app"/"static")),name="static")
templates=Jinja2Templates(directory=str(BASE_DIR/"app"/"templates"))
app.include_router(auth.router); app.include_router(planners.router); app.include_router(history.router)
@app.get("/api/health")
def health(): return {"status":"ok","app":APP_NAME,"ai_configured":bool(GEMINI_API_KEY),"model":GEMINI_MODEL if GEMINI_API_KEY else None}
@app.get("/",response_class=HTMLResponse)
def index(request:Request): return templates.TemplateResponse(request=request,name="index.html",context={"app_name":APP_NAME})
