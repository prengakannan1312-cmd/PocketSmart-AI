import json
from urllib.parse import quote_plus
from app.config import GEMINI_API_KEY, GEMINI_MODEL

def money(n, c):
    return f"{ {'INR':'₹','USD':'$','GBP':'£','EUR':'€'}.get(c, c+' ') }{n:,.0f}"
def links(query):
    q=quote_plus(query)
    return [{"platform":"Amazon","url":f"https://www.amazon.in/s?k={q}"},
            {"platform":"Flipkart","url":f"https://www.flipkart.com/search?q={q}"},
            {"platform":"Google Shopping","url":f"https://www.google.com/search?tbm=shop&q={q}"}]

def fallback(planner, d):
    budget=float(d["budget"]); currency=d.get("currency","INR"); items=[]
    if planner=="home":
        names=(d.get("items") or ["Lighting","Storage","Decor"])[:4]
        weights=[.35,.30,.20,.15][:len(names)]
        title=f"{d.get('room_type','Room')} interior plan"
        summary="A starter plan balancing essentials and style. Compare dimensions, materials, delivery, and reviews before buying."
        for name,w in zip(names,weights):
            amount=budget*w/sum(weights)
            items.append({"name":f"{d.get('style','Modern')} {name}","estimated_price":round(amount),"price_display":money(amount,currency),"reason":f"Suggested allocation: {w/sum(weights):.0%} of the budget.","search_links":links(f"{d.get('style','modern')} {name} {d.get('room_type','room')}")})
    elif planner=="party":
        names=(d.get("priorities") or ["Food","Decoration","Venue"])[:5]
        weights=[{"Food":.45,"Catering":.45,"Venue":.25,"Decoration":.15,"Entertainment":.10,"Photography":.05}.get(n,.2) for n in names]
        title=f"{d.get('event_type','Event')} plan for {d.get('guests',1)} guests"
        summary="Use allocations as a starting point. Ask vendors for written quotes and check taxes, travel, setup, and cancellation fees."
        for name,w in zip(names,weights):
            amount=budget*w/sum(weights)
            items.append({"name":name,"estimated_price":round(amount),"price_display":money(amount,currency),"reason":f"Suggested allocation: {w/sum(weights):.0%} of the budget.","search_links":links(f"{name} for {d.get('event_type','event')} {d.get('guests',1)} guests")})
    else:
        choices=[("Everyday minimal piece",.25,"Versatile and easy to rewear."),("Occasion statement piece",.45,"Adds a focal point for the occasion."),("Matching accessory set",.30,"Coordinates with your outfit and style.")]
        title=f"Jewelry ideas for {d.get('occasion','your occasion')}"
        summary="These are budget allocations, not verified product prices. Check purity, hallmarking, return terms, and seller authenticity."
        for name,w,reason in choices:
            amount=budget*w
            items.append({"name":name,"estimated_price":round(amount),"price_display":money(amount,currency),"reason":reason,"search_links":links(f"{d.get('style','classic')} {d.get('material','any')} jewelry {d.get('outfit_color','')} {name}")})
    return {"title":title,"summary":summary,"currency":currency,"budget":budget,"total_estimated":round(sum(i["estimated_price"] for i in items)),"items":items,"source":"fallback","disclaimer":"Planning estimates only. Links are searches; live inventory and prices are not verified."}

def call_gemini(prompt, image_bytes=None, mime_type=None):
    if not GEMINI_API_KEY: return None
    try:
        from google import genai
        from google.genai import types
        client=genai.Client(api_key=GEMINI_API_KEY)
        content=[prompt]
        if image_bytes and mime_type: content.append(types.Part.from_bytes(data=image_bytes,mime_type=mime_type))
        return client.models.generate_content(model=GEMINI_MODEL,contents=content).text
    except Exception:
        return None

def generate_recommendations(planner, data, image_bytes=None, mime_type=None):
    base=fallback(planner,data)
    prompt=("Return ONLY valid JSON with title, summary, and items (3-6 objects with name, estimated_price number, reason, search_query). "
    "Keep sum of prices at or below budget. Do not claim live inventory, verified current prices, or vendor API access. "
    f"Planner={planner}; currency={data.get('currency','INR')}; budget={data['budget']}; input={json.dumps(data,ensure_ascii=False)}")
    raw=call_gemini(prompt,image_bytes,mime_type)
    if raw:
        try:
            raw=raw.strip()
            if raw.startswith("```"): raw=raw.split("\n",1)[1].rsplit("```",1)[0].strip()
            parsed=json.loads(raw); remaining=float(data["budget"]); out=[]
            for it in parsed.get("items",[])[:6]:
                price=min(max(float(it.get("estimated_price",0)),0),remaining)
                if price<=0: continue
                out.append({"name":str(it.get("name","Suggested option"))[:120],"estimated_price":round(price),"price_display":money(price,data.get("currency","INR")),"reason":str(it.get("reason",""))[:400],"search_links":links(str(it.get("search_query") or it.get("name") or planner)[:160])})
                remaining-=price
            if out:
                return {"title":str(parsed.get("title") or base["title"])[:140],"summary":str(parsed.get("summary") or base["summary"])[:1000],"currency":data.get("currency","INR"),"budget":float(data["budget"]),"total_estimated":round(sum(x["estimated_price"] for x in out)),"items":out,"source":"gemini","disclaimer":base["disclaimer"]}
        except (ValueError,TypeError,AttributeError): pass
    return base
