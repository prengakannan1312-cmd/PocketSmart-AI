from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from passlib.context import CryptContext
from app.config import SECRET_KEY, ACCESS_TOKEN_MINUTES
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
def hash_password(password: str) -> str:
    return pwd_context.hash(password)
def verify_password(password: str, password_hash: str) -> bool:
    return pwd_context.verify(password, password_hash)
def create_access_token(user_id: int, email: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_MINUTES)
    return jwt.encode({"sub": str(user_id), "email": email, "exp": exp}, SECRET_KEY, algorithm="HS256")
def decode_access_token(token: str):
    try:
        p = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return {"id": int(p["sub"]), "email": p["email"]}
    except (JWTError, ValueError, KeyError, TypeError):
        return None
