from pydantic import BaseModel, EmailStr, Field
class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=72)
class HomeRequest(BaseModel):
    budget: float = Field(gt=0, le=100000000)
    room_type: str = Field(min_length=2, max_length=60)
    style: str = Field(default="Modern", max_length=60)
    currency: str = Field(default="INR", pattern="^(INR|USD|GBP|EUR)$")
    items: list[str] = Field(default_factory=lambda: ["Lighting","Storage","Decor"], max_length=12)
    notes: str = Field(default="", max_length=500)
class PartyRequest(BaseModel):
    budget: float = Field(gt=0, le=100000000)
    event_type: str = Field(min_length=2, max_length=60)
    guests: int = Field(gt=0, le=100000)
    venue: str = Field(default="Flexible", max_length=100)
    currency: str = Field(default="INR", pattern="^(INR|USD|GBP|EUR)$")
    priorities: list[str] = Field(default_factory=lambda: ["Food","Decoration","Venue"], max_length=8)
    notes: str = Field(default="", max_length=500)
class JewelryRequest(BaseModel):
    budget: float = Field(gt=0, le=100000000)
    occasion: str = Field(min_length=2, max_length=80)
    style: str = Field(default="Classic", max_length=80)
    outfit_color: str = Field(default="Not specified", max_length=80)
    material: str = Field(default="Any", max_length=80)
    currency: str = Field(default="INR", pattern="^(INR|USD|GBP|EUR)$")
    notes: str = Field(default="", max_length=500)
