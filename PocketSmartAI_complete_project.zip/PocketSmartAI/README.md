# PocketSmart AI
Budget-aware recommendations for home interiors, party planning, and jewelry.

## Run on Windows / VS Code
1. Extract this ZIP and open the `PocketSmartAI` folder in VS Code.
2. In Terminal → New Terminal run:
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```
   If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` and activate again.
3. Copy `.env.example` to `.env`. Add a Google AI Studio API key to `GEMINI_API_KEY` to enable Gemini; without a key, local fallback recommendations work.
4. Run `uvicorn app.main:app --reload`
5. Open `http://127.0.0.1:8000`. API docs: `http://127.0.0.1:8000/docs`.
6. Test with `pytest -q`.

The database is created automatically. This demo uses product-search links, not live vendor APIs; prices and allocations are estimates. Change `SECRET_KEY` before deployment.
